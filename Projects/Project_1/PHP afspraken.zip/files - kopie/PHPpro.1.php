<html>
  <body>
    Welkom <?php echo $_POST["name"]; ?><br>
    Uw email address is: <?php echo $_POST["email"]; ?> <br>
    Uw geslacht is: <?php echo $_POST["geslacht"]; ?>
  </body>
</html>
